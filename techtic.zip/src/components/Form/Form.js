import React, {useState} from "react";

const Form = ({addNewEmployee, updateEmployee, id='',  firstname='', lastname='',email='',phone='', dob=''}) => {

    const ErrorHandler = ({message}) => {
        return(
            <div className="text-danger mt-4">
                {message}
            </div>
        )
    }

    const [values, setValues] = useState({
        firstname: firstname,
        lastname: lastname,
        email: email,
        phone: phone,
        dob: dob
    });

    const [errors, setErrors] = useState('');

    const handleSubmit = (e) => {
        
        e.preventDefault();

        if(values.firstname === '' || values.lastname === '' || values.email === '' || values.phone === '' || values.dob === ''){
            setErrors('Please fill in all the fields');
        }else{
            if(id){
              updateEmployee(values);
            }else{
              addNewEmployee(values);
            }
        }
    } 
  
    const handleOnChange = (e) => {
    
        const {name, value} = e.target;
    
        setValues({
            ...values,
            [name]: value
        });
  }
  return (
    <>
    {errors ? <ErrorHandler message={errors} /> : ''}
    <form className="mt-4" onSubmit={handleSubmit}>
      <div class="form-group mb-3">
        <label for="firstname">First Name</label>
        <input
          type="text"
          class="form-control"
          id="firstname"
          name="firstname"
          placeholder="Enter First Name"
          onChange={handleOnChange}
          value={values.firstname}
        />
      </div>
      <div class="form-group mb-3">
        <label for="lastname">Last Name</label>
        <input
          type="text"
          class="form-control"
          id="lastname"
          name="lastname"
          placeholder="Enter Last Name"
          onChange={handleOnChange}
          value={values.lastname}
        />
      </div>
      <div class="form-group mb-3">
        <label for="email">Email</label>
        <input
          type="text"
          class="form-control"
          id="email"
          name="email"
          placeholder="Enter Email"
          onChange={handleOnChange}
          value={values.email}
        />
      </div>
      <div class="form-group mb-3">
        <label for="email">Phone</label>
        <input
          type="text"
          class="form-control"
          id="phone"
          name="phone"
          placeholder="Enter Phone"
          onChange={handleOnChange}
          value={values.phone}
        />
      </div>
      <div class="form-group mb-3">
        <label for="dob" style={{marginRight: '10px'}}>Date of Birth</label>
        <input type="date" id="dob" name="dob" onChange={handleOnChange} value={values.dob}></input>
      </div>
      <button type="submit" class="btn btn-primary">
        Submit
      </button>
    </form>
    </>
  );
};

export default Form;
