import { createSlice } from "@reduxjs/toolkit";

const initialState = [
  { employeeid: null, leaves: [] },
];

const leavesSlice = createSlice({
  name: "leaves",
  initialState,
  reducers: {
    leavelogged(state, action) {
      const { employeeid, leaveid, leavereason, leavedays } = action.payload;

      const EmployeeLeaveRecord = state.find(
        (employee) => employee.employeeid == employeeid
      );

      if (EmployeeLeaveRecord) {
        EmployeeLeaveRecord.leaves.push({
          id: leaveid,
          leavereason: leavereason,
          days: leavedays,
        });
      } else {
        state.push({
          employeeid: employeeid,
          leaves: [
            {
              id: leaveid,
              leavereason: leavereason,
              days: leavedays,
            },
          ],
        });
      }
    },
    leavedeleted(state, action) {
      const { employeeId, leaveId } = action.payload;

      const existingLeave = state.find(
        (leave) => leave.employeeid == employeeId
      );
    },
    allleavesdeleted(state, action){
      const { id } = action.payload;
           
      const existingLeaveRecord = state.find(
        (leave) => leave.employeeid == id
      );

      if(existingLeaveRecord){
        return state.filter((employee) => employee.employeeid !== id);
      }
    }
  },
});

export const { leavelogged, leavedeleted, allleavesdeleted } = leavesSlice.actions;

export default leavesSlice.reducer;
