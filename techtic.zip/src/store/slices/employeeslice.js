import { createSlice } from "@reduxjs/toolkit";

const initialState = [
    { id: 1, firstname: "Siddharth", lastname: "Desai", email: "siddharthkamleshdesai@gmail.com", phone: '9039618065', dob: '1993-09-01' },
];

const employeeslice = createSlice({
    name: "employees",
    initialState,
    reducers: {
        employeeCreated(state, action){
            state.push(action.payload)
        },
        employeeUpdated(state, action){
            const { id, firstname, lastname, email, phone, dob } = action.payload;

            const existingEmployee = state.find((employee) => employee.id == id);

            if (existingEmployee) {
                existingEmployee.firstname = firstname;
                existingEmployee.lastname = lastname;
                existingEmployee.email = email;
                existingEmployee.phone = phone;
                existingEmployee.dob = dob;
            }
        },
        employeeDeleted(state, action) {
            const { id } = action.payload;
            const existingUser = state.find((employee) => employee.id == id);
            if (existingUser) {
              return state.filter((employee) => employee.id !== id);
            }
        },
    }
})

export const { employeeCreated, employeeUpdated, employeeDeleted } = employeeslice.actions;

export default employeeslice.reducer;