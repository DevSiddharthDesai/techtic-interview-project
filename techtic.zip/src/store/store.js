import {combineReducers} from 'redux';
import { configureStore } from "@reduxjs/toolkit";
import thunk from 'redux-thunk';
import { persistStore, persistReducer } from 'redux-persist';
import storage from 'redux-persist/lib/storage';
import employeeReducer from './slices/employeeslice';
import leavesReducer from './slices/leavesSlice';

const persistConfig = {
    key: "root",
    storage,
};

export const rootReducer = combineReducers({
    employees: employeeReducer,
    leaves: leavesReducer,
});

const persistedReducer = persistReducer(persistConfig, rootReducer);

export const store = configureStore({
    reducer: persistedReducer,
    undefined,
    middleware: [thunk]
});

export const persistor = persistStore(store);

