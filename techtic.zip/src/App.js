import './App.css';
import {Routes, Route} from 'react-router-dom';
import Add from './pages/Employees/Add';
import Edit from './pages/Employees/Edit';
import List from './pages/Employees/List';
import AddLeaves from './pages/Leaves/Add';

function App() {
  return (
    <Routes>
        <Route path="/" element={<List/>} />
        <Route path="/add-employee" element={<Add/>} />
        <Route path="/edit-employee/:id" element={<Edit/>} />
        <Route path="/add-leave/:id" element={<AddLeaves/>} />
      </Routes>    
  );
}

export default App;
