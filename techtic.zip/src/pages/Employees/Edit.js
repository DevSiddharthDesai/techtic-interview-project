import React from 'react'
import { useSelector, useDispatch } from 'react-redux';
import { Link, useNavigate } from "react-router-dom";
import { employeeUpdated } from "../../store/slices/employeeslice";
import Form from "../../components/Form/Form";
import { useParams } from 'react-router-dom';

const Edit = () => {

  const { id } = useParams();

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const employee = useSelector((state) =>
    state.employees.find((employee) => employee.id == id));

  const updateEmployee = (values) => {
    const {firstname, lastname, email, phone, dob} = values;

    dispatch(
      employeeUpdated({
        id: employee.id,
        firstname,
        lastname,
        email,
        phone,
        dob
      }));

    navigate('/');
  }

  return (
    <div className="container mt-4">
      <h1>Add Employee</h1>
      <Link to="/">
      <button className="btn btn-primary mt-4">Back to Employee List</button>
      </Link>
      <Form updateEmployee={updateEmployee} id={employee.id} firstname={employee.firstname} lastname={employee.lastname} email={employee.email} phone={employee.phone} dob={employee.dob} />
    </div>
  )
}

export default Edit