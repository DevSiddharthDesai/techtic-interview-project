import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { employeeDeleted } from "../../store/slices/employeeslice";
import { leavedeleted, allleavesdeleted } from "../../store/slices/leavesSlice";
import Modal from "react-bootstrap/Modal";
import ModalBody from "react-bootstrap/ModalBody";
import ModalHeader from "react-bootstrap/ModalHeader";
import ModalFooter from "react-bootstrap/ModalFooter";
import ModalTitle from "react-bootstrap/ModalTitle";

const List = () => {
  const employeesList = useSelector((state) => state.employees);

  const leavesList = useSelector((state) => state.leaves);

  const dispatch = useDispatch();

  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [leaveModalOpen, setLeaveModalOpen] = useState(false);
  const [deleteLeaveModalOpen, setDeleteLeaveModalOpen] = useState(false);

  const [employeeId, setEmployeeId] = useState(null);
  const [leaveId, setLeaveId] = useState(null);
  const [leaves, setLeaves] = useState([]);

  const deleteEmployee = () => {
    dispatch(employeeDeleted({ id: employeeId }));
    dispatch(allleavesdeleted({ id: employeeId }));
    setDeleteModalOpen(false);
  };

  const showLeaves = (id) => {
    setLeaveModalOpen(true);
    const EmployeeLeave = leavesList.find(
      (employee) => employee.employeeid == id
    );
    setEmployeeId(EmployeeLeave.employeeid);
    setLeaves(EmployeeLeave.leaves);
  };

  const deleteLeave = () => {
    dispatch(leavedeleted({employeeId: employeeId,leaveId: leaveId}));
  }

  return (
    <>
      <Modal show={deleteModalOpen}>
        <ModalHeader>
          <ModalTitle>Delete Employee</ModalTitle>
        </ModalHeader>
        <ModalBody>Are you sure you want to delete employee?</ModalBody>
        <ModalFooter>
          <button
            type="button"
            className="btn btn-primary"
            onClick={() => setDeleteModalOpen(false)}
          >
            Cancel
          </button>
          <button
            type="button"
            className="btn btn-danger"
            onClick={deleteEmployee}
          >
            Delete
          </button>
        </ModalFooter>
      </Modal>
      <Modal show={leaveModalOpen}>
        <ModalHeader>
          <ModalTitle>Leaves</ModalTitle>
        </ModalHeader>
        <ModalBody>
          <table className="table table-bordered mt-4">
            <thead>
              <tr>
                <th scope="col">Leave Reason</th>
                <th scope="col">Leave Days</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              {leaves.map((leave) => {
                return (
                  <>
                    <tr key={leave.id}>
                      <td>{leave.leavereason}</td>
                      <td>{leave.days}</td>
                      <td><button type="button" className="btn btn-danger" onClick={() => {
                        setDeleteLeaveModalOpen(true);
                        setLeaveId(leave.id);
                      }}>Delete</button></td>
                    </tr>
                  </>
                );
              })}
            </tbody>
          </table>
        </ModalBody>
      </Modal>
      <Modal show={deleteLeaveModalOpen}>
        <ModalHeader>
          <ModalTitle>Delete Leave</ModalTitle>
        </ModalHeader>
        <ModalBody>
          Are you sure you want to delete leave?
        </ModalBody>
        <ModalFooter>
          <button
            type="button"
            className="btn btn-primary"
            onClick={() => setDeleteModalOpen(false)}
          >
            Cancel
          </button>
          <button
            type="button"
            className="btn btn-danger"
            onClick={deleteLeave}
          >
            Delete
          </button>
        </ModalFooter>
      </Modal>
      <div className="container mt-4">
        <h1>Employee List</h1>
        <Link to="/add-employee">
          <button className="btn btn-primary mt-4">Add User</button>
        </Link>
        <table className="table table-bordered mt-4">
          <thead>
            <tr>
              <th scope="col">First Name</th>
              <th scope="col">Last Name</th>
              <th scope="col">Email</th>
              <th scope="col">Phone</th>
              <th scope="col">DOB</th>
              <th scope="col">Actions</th>
            </tr>
          </thead>
          <tbody>
            {employeesList.map(
              ({ id, firstname, lastname, email, phone, dob }) => {
                return (
                  <tr key={email}>
                    <td>{firstname}</td>
                    <td>{lastname}</td>
                    <td>{email}</td>
                    <td>{phone}</td>
                    <td>{dob}</td>
                    <td>
                      <Link to={`/edit-employee/${id}`}>
                        <button className="btn btn-primary me-3">Edit</button>
                      </Link>
                      <button
                        id={id}
                        type="button"
                        className="btn btn-danger me-3"
                        onClick={() => {
                          setDeleteModalOpen(true);
                          setEmployeeId(id);
                        }}
                      >
                        Delete
                      </button>
                      <Link to={`/add-leave/${id}`}>
                        <button type="button" className="btn btn-info me-3">
                          Add Leave
                        </button>
                      </Link>
                      {leavesList.find(
                      (employee) => employee.employeeid == id) ?
                      <button
                        type="button"
                        className="btn btn-info me-3"
                        onClick={() => showLeaves(id)}
                      >
                        Show Leaves
                      </button>
                      : ''}
                    </td>
                  </tr>
                );
              }
            )}
          </tbody>
        </table>
      </div>
    </>
  );
};

export default List;
