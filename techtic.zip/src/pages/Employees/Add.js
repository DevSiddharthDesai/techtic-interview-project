import React from "react";
import { Link, useNavigate } from "react-router-dom";
import Form from "../../components/Form/Form";
import { useSelector, useDispatch } from 'react-redux';
import { employeeCreated } from "../../store/slices/employeeslice";

const Add = () => {

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const employeeListLength = useSelector((state) => state.employees.length);

  const addNewEmployee = (values) => {
    const {firstname, lastname, email, phone, dob} = values;
    dispatch(
      employeeCreated({
        id: employeeListLength + 1,
        firstname:firstname,
        lastname:lastname,
        email:email,
        phone:phone,
        dob:dob
    }));
    navigate('/');
  }

  return (
    <div className="container mt-4">
      <h1>Add Employee</h1>
      <Link to="/">
        <button className="btn btn-primary mt-4">Back to Employee List</button>
      </Link>
      <Form addNewEmployee={addNewEmployee} />
    </div>
  );
};

export default Add;
