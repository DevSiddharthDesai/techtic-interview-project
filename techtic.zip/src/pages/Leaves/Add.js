import React, { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import { leavelogged } from "../../store/slices/leavesSlice";
import { useParams } from "react-router-dom";

const Add = () => {
  const { id } = useParams();

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const leavesList = useSelector((state) =>
    state.leaves.find((employee) => employee.employeeid == id));

  const [values, setValues] = useState({
    employeeid: id,
    leaveid: leavesList ? leavesList.length + 1 : 1,
    leavereason: "",
    leavedays: null,
  });

  const handleOnChange = (e) => {
    const { name, value } = e.target;

    setValues({
      ...values,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(leavelogged(values));
    navigate('/');
  };

  return (
    <>  
      <div className="container mt-4">
        <h1>Add Leave</h1>
        <Link to="/">
            <button className="btn btn-primary mt-4">Back to Employee List</button>
        </Link>
        <form className="mt-4" onSubmit={handleSubmit}>
          <div class="form-group mb-3">
            <label for="leavereason">Leave Reason</label>
            <input
              type="text"
              class="form-control"
              id="leavereason"
              name="leavereason"
              placeholder="Enter Leave Reason"
              onChange={handleOnChange}
            />
          </div>
          <div class="form-group mb-3">
            <label for="leavedays">No. of Leave Days</label>
            <input
              type="number"
              class="form-control"
              id="leavedays"
              name="leavedays"
              placeholder="Enter Leave Days"
              onChange={handleOnChange}
            />
          </div>
          <button type="submit" class="btn btn-primary">
            Submit
          </button>
        </form>
      </div>
    </>
  );
};

export default Add;
